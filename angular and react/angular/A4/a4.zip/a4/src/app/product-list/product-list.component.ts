import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-product-list',
  template: `
    <p>
      product-list works!
    </p>
  `,
  styles: [
  ]
})
export class ProductListComponent implements OnInit {
  constructor() { }
  ngOnInit(): void {
  }
}