import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-list',
  template: `
    <p>
      customer-list works!
    </p>
  `,
  styles: [
  ]
})
export class CustomerListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
